import React from "react";

const GoalsHeader = () => {
  return <div className="goalsHeader">Community Goals</div>;
};

export default GoalsHeader;
