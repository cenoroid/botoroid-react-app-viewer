import React from "react";

const StoreHeader = () => {
  return <div className="storeHeader">Store</div>;
};

export default StoreHeader;
