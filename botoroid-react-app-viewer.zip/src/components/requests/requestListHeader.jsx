import React from "react";

const RequestListHeader = () => {
  return <div className="requestListHeader">Request List</div>;
};

export default RequestListHeader;
